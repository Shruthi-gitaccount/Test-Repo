package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import org.junit.Assert;

public class FollowupsSteps extends InitializeTest {
    @Given("Get a organization details with orgaizationId {int}")
    public void get_a_organization_details_with_orgaizationId(int organizationId) {
        RestAssured.baseURI  =  myranConfig.getBaseUrl();
        response = RestAssured.given().
                request().
                contentType("application/json").request().
                header("Authorization", "bearer "+ accessToken).
                when().get("/followups/latest?organizationId="+ organizationId);

    }

    @Then("Organization should be found and Status_code equals {int}")
    public void organization_should_be_found_and_Status_code_equals(int statusCode) {
        Assert.assertEquals(statusCode, response.getStatusCode());
    }
    @Given("A list of latest followups are available")
    public void a_list_of_latest_followups_are_available() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @Given("A list of all followups are available")
    public void a_list_of_all_followups_are_available() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @When("Add a followup to an organization")
    public void add_a_followup_to_an_organization() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @When("Update a followp for an organization with ID")
    public void update_a_followp_for_an_organization_with_ID() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
    @When("Delete a followup with an ID")
    public void delete_a_followup_with_an_ID() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }
}
